const $ = s => document.querySelector(s);
const q = new URLSearchParams(location.search);
const ruleId = q.get("rule");
const from = q.get("from") || "";
let autoClose = 0;

// Close this tab; if it's the last tab in the window, open a new tab page instead
// so the whole browser window doesn't disappear.
async function closeTab() {
  clearTimeout(autoClose);
  const me = await chrome.tabs.getCurrent();
  if (!me) { window.close(); return; }
  const siblings = await chrome.tabs.query({ windowId: me.windowId });
  if (siblings.length > 1) await chrome.tabs.remove(me.id);
  else await chrome.tabs.update(me.id, { url: "chrome://newtab/" });
}

async function init() {
  const { settings, usage, extra } = await loadAll();
  const rule = settings.rules.find(r => r.id === ruleId);
  const d = dayKey();
  const name = rule ? rule.label : "this site";
  const usedMin = Math.floor(((usage[d] || {})[ruleId] || 0) / 60);
  const bonus = (extra[d] || {})[ruleId] || 0;

  document.title = "Time's up: " + name + " · TaktOwl";
  $("#title").textContent = "Time's up for " + name;
  if (inBedtime(settings)) {
    $("#title").textContent = "It's bedtime";
    $("#used").textContent = "CLOSED UNTIL " + settings.bedTo;
    $("#sub").textContent = name + " stays closed until " + settings.bedTo + ". Sleep is when today's studying turns into memory.";
  } else if (rule && rule.minutes === 0) {
    $("#used").textContent = "0 MIN ALLOWED";
    $("#sub").textContent = name + " is set to 0 minutes, so it stays closed all day. Change that in the TaktOwl Guard menu.";
  } else if (rule) {
    $("#used").textContent = usedMin + " / " + (rule.minutes + bonus / 60) + " MIN TODAY";
    $("#sub").textContent = "You've used today's minutes on " + name + ". It opens again tomorrow.";
  }

  const canExtend = rule && rule.minutes > 0 && settings.allowExtra && !bonus && !inBedtime(settings) && /^https?:/.test(from);
  if (canExtend) {
    $("#extraBtn").hidden = false;
    $("#extraBtn").addEventListener("click", async () => {
      clearTimeout(autoClose);
      const fresh = await chrome.storage.local.get("extra");
      const ex = fresh.extra || {};
      ex[d] = ex[d] || {};
      ex[d][ruleId] = EXTRA_SECONDS;
      for (const k of Object.keys(ex)) if (k < daysAgo(3)) delete ex[k];
      await chrome.storage.local.set({ extra: ex });
      location.replace(from);
    });
  }
  $("#closeBtn").addEventListener("click", closeTab);

  if (settings.action === "close" && !canExtend) {
    $("#closing").textContent = "Closing this tab…";
    autoClose = setTimeout(closeTab, 2800);
  } else if (settings.action === "close") {
    let n = 8;
    const t = () => {
      $("#closing").textContent = "Closing this tab in " + n + " s…";
      if (n-- <= 0) closeTab(); else autoClose = setTimeout(t, 1000);
    };
    t();
  }
}
init();
