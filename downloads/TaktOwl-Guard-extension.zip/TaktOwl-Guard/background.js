// TaktOwl Guard: counts the time you spend on the sites you name
// and closes the tab when the day's minutes run out.
importScripts("common.js");

const TICK_CAP = 90; // never credit more than 90 s per flush (sleep, missed events)

// Run handlers one at a time so usage writes never race.
let chain = Promise.resolve();
function serial(fn) { chain = chain.then(fn).catch(e => console.warn("TaktOwl:", e)); return chain; }

// Credit the time since the last flush to the site in front.
async function flush() {
  const { cur } = await chrome.storage.session.get("cur");
  if (!cur) return;
  const now = Date.now();
  const raw = Math.floor((now - cur.since) / 1000);
  const secs = Math.min(TICK_CAP, raw);
  if (secs > 0) {
    const { usage = {} } = await chrome.storage.local.get("usage");
    const d = dayKey();
    usage[d] = usage[d] || {};
    usage[d][cur.ruleId] = (usage[d][cur.ruleId] || 0) + secs;
    const oldest = daysAgo(14);
    for (const k of Object.keys(usage)) if (k < oldest) delete usage[k];
    await chrome.storage.local.set({ usage });
  }
  cur.since = raw > TICK_CAP ? now : cur.since + secs * 1000;
  await chrome.storage.session.set({ cur });
}

async function stopCounting(badge) {
  await chrome.storage.session.remove("cur");
  await chrome.alarms.clear("deadline");
  await chrome.action.setBadgeText({ text: badge || "" });
}

// One breath first: the tab goes to the owl's pause page, which sends it back if you choose to continue.
async function needsPause(settings, rule) {
  if (!settings.pause) return false;
  const { admitted = {} } = await chrome.storage.session.get("admitted");
  return !(admitted[rule.id] && Date.now() - admitted[rule.id] < READMIT_MINUTES * 60000);
}

async function admit(ruleId) {
  const { admitted = {} } = await chrome.storage.session.get("admitted");
  admitted[ruleId] = Date.now();
  await chrome.storage.session.set({ admitted: admitted });
}

async function toPause(tab, rule) {
  const url = chrome.runtime.getURL("pause.html?rule=" + encodeURIComponent(rule.id) + "&from=" + encodeURIComponent(tab.url));
  try { await chrome.tabs.update(tab.id, { url }); } catch (e) { /* tab already gone */ }
}

async function swat(tab, rule) {
  const url = chrome.runtime.getURL("blocked.html?rule=" + encodeURIComponent(rule.id) + "&from=" + encodeURIComponent(tab.url));
  try { await chrome.tabs.update(tab.id, { url }); } catch (e) { /* tab already gone */ }
}

// Work out which watched site (if any) is in front of the user right now.
async function evaluate() {
  await flush();
  const { settings, usage, extra } = await loadAll();
  if (settings.snoozeUntil > Date.now()) return stopCounting("zz");

  let win = null;
  try { win = await chrome.windows.getLastFocused(); } catch (e) {}
  if (!win || !win.focused) return stopCounting();
  const [tab] = await chrome.tabs.query({ active: true, windowId: win.id });
  const rule = tab && tab.url ? matchRule(tab.url, settings.rules) : null;
  if (!rule) return stopCounting();

  const left = secondsLeft(rule, usage, extra, settings);
  if (left <= 0) { await stopCounting(); return swat(tab, rule); }
  if (await needsPause(settings, rule)) { await stopCounting(); return toPause(tab, rule); }
  await admit(rule.id);   // still here: keep the pass fresh

  const { cur } = await chrome.storage.session.get("cur");
  if (!cur || cur.tabId !== tab.id || cur.ruleId !== rule.id) {
    await chrome.storage.session.set({ cur: { tabId: tab.id, ruleId: rule.id, since: Date.now() } });
  }
  await chrome.alarms.create("deadline", { when: Date.now() + left * 1000 + 250 });
  await chrome.action.setBadgeText({ text: left >= 60 ? Math.ceil(left / 60) + "m" : left + "s" });
}

// A tab opening or navigating to a site that's already used up gets closed,
// even in the background.
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (!info.url && info.status !== "complete") return;
  serial(async () => {
    const { settings, usage, extra } = await loadAll();
    if (!(settings.snoozeUntil > Date.now())) {
      const rule = tab.url ? matchRule(tab.url, settings.rules) : null;
      if (rule && secondsLeft(rule, usage, extra, settings) <= 0) {
        if (tab.active) await flush();
        return swat(tab, rule);
      }
    }
    if (tab.active) return evaluate();
  });
});
chrome.tabs.onActivated.addListener(() => serial(evaluate));
chrome.tabs.onRemoved.addListener(() => serial(evaluate));
chrome.windows.onFocusChanged.addListener(() => serial(evaluate));
chrome.idle.onStateChanged.addListener(state => serial(async () => {
  if (state === "locked") { await flush(); await stopCounting(); }
  else await evaluate();
}));
chrome.alarms.onAlarm.addListener(() => serial(evaluate));
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === "local" && (ch.settings || ch.extra)) serial(evaluate);
});
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg && msg.type === "flush") { serial(flush).then(() => reply(true)); return true; }
});

async function setup() {
  const { settings } = await chrome.storage.local.get("settings");
  if (!settings) await chrome.storage.local.set({ settings: Object.assign({}, DEFAULTS, { installedOn: dayKey() }) });
  await chrome.alarms.create("tick", { periodInMinutes: 0.5 });
  await chrome.action.setBadgeBackgroundColor({ color: "#E3A21A" });
  if (chrome.action.setBadgeTextColor) await chrome.action.setBadgeTextColor({ color: "#2E2000" });
  chrome.idle.setDetectionInterval(60);
  serial(evaluate);
}
chrome.runtime.onInstalled.addListener(setup);
chrome.runtime.onStartup.addListener(setup);
