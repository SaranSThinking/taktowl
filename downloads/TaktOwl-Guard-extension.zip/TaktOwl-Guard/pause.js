// One breath before a limited site: in for 4 s, out for 6 s, then choose.
const $ = s => document.querySelector(s);
const q = new URLSearchParams(location.search);
const ruleId = q.get("rule");
const from = q.get("from") || "";
const started = Date.now();

async function init() {
  const { settings, usage } = await loadAll();
  const rule = settings.rules.find(r => r.id === ruleId);
  const name = rule ? rule.label : "this site";
  const usedMin = Math.floor(((usage[dayKey()] || {})[ruleId] || 0) / 60);
  const st = await bumpStat(ruleId, "open");
  document.title = "One breath: " + name + " · TaktOwl";
  $("#stats").textContent = "Opened " + st.open + (st.open === 1 ? " time" : " times") + " today" +
    (rule ? " · " + usedMin + " of " + rule.minutes + " minutes used" : "");

  const tick = () => {
    const t = (Date.now() - started) / 1000;
    $("#bar").style.width = Math.min(100, t / PAUSE_SECONDS * 100) + "%";
    if (t >= PAUSE_SECONDS) {
      $("#card").classList.add("done");
      $("#title").textContent = "Still want to open " + name + "?";
      $("#go").disabled = false;
      $("#go").textContent = "Open " + name;
      return;
    }
    $("#title").textContent = (t % 10) < 4 ? "Breathe in…" : "Breathe out…";
    $("#go").textContent = "Open " + name + " (" + Math.ceil(PAUSE_SECONDS - t) + ")";
    setTimeout(tick, 200);
  };
  tick();

  $("#go").addEventListener("click", async () => {
    const { admitted = {} } = await chrome.storage.session.get("admitted");
    admitted[ruleId] = Date.now();
    await chrome.storage.session.set({ admitted: admitted });
    if (/^https?:/.test(from)) location.replace(from); else closeThisTab();
  });
  $("#back").addEventListener("click", async () => {
    await bumpStat(ruleId, "back");
    closeThisTab();
  });
  document.addEventListener("keydown", e => { if (e.key === "Escape") $("#back").click(); });
  $("#back").focus();
}
init();
