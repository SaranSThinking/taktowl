const $ = s => document.querySelector(s);
let st = null;

async function refresh() {
  try { await chrome.runtime.sendMessage({ type: "flush" }); } catch (e) {}
  st = await loadAll();
  const a = document.activeElement;
  if (a && a.tagName === "INPUT" && a.type !== "checkbox") return; // don't wipe a field being typed in
  render();
}

function clone(o) { return JSON.parse(JSON.stringify(o)); }

// Every change goes through here. Stricter changes apply now (and to anything queued for
// tomorrow); with commitment mode on, looser ones are queued until tomorrow.
// Commitment mode starts the day after installing, so setting up is never a trap.
function firstDay() { return st.settings.installedOn === dayKey(); }

async function change(fn, loosens) {
  if (st.settings.commit && loosens && !firstDay()) {
    const next = st.pending ? clone(st.pending.settings) : clone(st.settings);
    fn(next);
    st.pending = { applyOn: tomorrow(), settings: next };
    await chrome.storage.local.set({ pending: st.pending });
    $("#msg").textContent = "Saved for tomorrow. Stricter settings start now; looser ones wait a day.";
  } else {
    fn(st.settings);
    await chrome.storage.local.set({ settings: st.settings });
    if (st.pending) {
      fn(st.pending.settings);
      await chrome.storage.local.set({ pending: st.pending });
    }
    $("#msg").textContent = "";
  }
  render();
}

function mins(sec) { return Math.floor(sec / 60); }

function pendingSummary() {
  if (!st.pending) return "";
  const cur = st.settings, nx = st.pending.settings, parts = [];
  nx.rules.forEach(n => {
    const o = cur.rules.find(r => r.id === n.id);
    if (!o) parts.push("add " + n.label);
    else if (o.minutes !== n.minutes) parts.push(n.label + " " + o.minutes + " → " + n.minutes + " min");
  });
  cur.rules.forEach(o => { if (!nx.rules.some(n => n.id === o.id)) parts.push("remove " + o.label); });
  if (cur.pause !== nx.pause) parts.push("pause " + (nx.pause ? "on" : "off"));
  if (cur.commit !== nx.commit) parts.push("commitment mode " + (nx.commit ? "on" : "off"));
  if (cur.bedtime !== nx.bedtime) parts.push("bedtime lock " + (nx.bedtime ? "on" : "off"));
  if (cur.bedFrom !== nx.bedFrom || cur.bedTo !== nx.bedTo) parts.push("bedtime " + nx.bedFrom + "–" + nx.bedTo);
  if (cur.allowExtra !== nx.allowExtra) parts.push("5-minute extensions " + (nx.allowExtra ? "on" : "off"));
  return parts.length ? "Starting tomorrow: " + parts.join("; ") + "." : "";
}

function render() {
  const d = dayKey(), used = st.usage[d] || {}, extra = st.extra[d] || {}, stats = st.stats[d] || {};
  const bed = inBedtime(st.settings);
  const list = $("#list");
  list.textContent = "";
  if (!st.settings.rules.length) {
    const li = document.createElement("li");
    li.textContent = "No sites yet. Add one below.";
    list.appendChild(li);
  }
  st.settings.rules.forEach(r => {
    const u = used[r.id] || 0, lim = bed ? 0 : r.minutes * 60 + (extra[r.id] || 0), over = u >= lim;
    const li = document.createElement("li");
    if (over) li.className = "over";

    const top = document.createElement("div"); top.className = "top";
    const name = document.createElement("span"); name.className = "name"; name.textContent = r.label;
    const num = document.createElement("span"); num.className = "num";
    const s = stats[r.id];
    num.textContent = bed ? "bedtime" : r.minutes === 0 ? "blocked" : over ? "time's up" : mins(u) + " / " + Math.round(lim / 60) + " min";
    if (s && s.open) num.textContent += " · back " + s.back + "/" + s.open;
    top.append(name, num);

    const bar = document.createElement("div"); bar.className = "bar";
    const fill = document.createElement("i"); fill.style.width = (lim ? Math.min(100, u / lim * 100) : 100) + "%";
    bar.appendChild(fill);

    const bot = document.createElement("div"); bot.className = "bot";
    const m = document.createElement("span"); m.className = "match"; m.textContent = r.match;
    const lab = document.createElement("label"); lab.className = "lim";
    const inp = document.createElement("input"); inp.className = "field"; inp.type = "number"; inp.min = "0"; inp.max = "600";
    inp.value = r.minutes; inp.id = "lim-" + r.id; inp.setAttribute("aria-label", "Minutes per day for " + r.label);
    inp.addEventListener("change", () => {
      const v = parseInt(inp.value, 10);
      if (isNaN(v)) { inp.value = r.minutes; return; }
      const val = Math.max(0, Math.min(600, v));
      change(s => { const x = s.rules.find(z => z.id === r.id); if (x) x.minutes = val; }, val > r.minutes);
    });
    lab.append(inp, document.createTextNode("min/day"));
    const x = document.createElement("button"); x.className = "x"; x.textContent = "×";
    x.setAttribute("aria-label", "Stop watching " + r.label);
    x.addEventListener("click", () => change(s => { s.rules = s.rules.filter(z => z.id !== r.id); }, true));
    bot.append(m, lab, x);

    li.append(top, bar, bot);
    list.appendChild(li);
  });

  $("#action").value = st.settings.action;
  $("#allowExtra").checked = !!st.settings.allowExtra;
  $("#pause").checked = !!st.settings.pause;
  $("#commit").checked = !!st.settings.commit;
  $("#bedtime").checked = !!st.settings.bedtime;
  $("#bedFrom").value = st.settings.bedFrom;
  $("#bedTo").value = st.settings.bedTo;
  const p = firstDay() && st.settings.commit
    ? "Setting up today: every change applies straight away. Commitment mode starts tomorrow."
    : pendingSummary();
  $("#pending").hidden = !p;
  $("#pending").textContent = p;

  const snoozed = st.settings.snoozeUntil > Date.now();
  $("#snooze").textContent = snoozed ? "Resume watching now" : st.settings.commit ? "Snooze 15 minutes (once a day)" : "Snooze for 15 minutes";
  if (snoozed) {
    const t = new Date(st.settings.snoozeUntil);
    $("#status").textContent = "Snoozed until " + pad(t.getHours()) + ":" + pad(t.getMinutes());
  } else if (bed) {
    $("#status").textContent = "Bedtime: limited sites stay closed until " + st.settings.bedTo;
  } else {
    const n = st.settings.rules.length;
    $("#status").textContent = "Watching " + n + " site" + (n === 1 ? "" : "s");
  }
}

// Minutes after 18:00, so 00:30 counts as later than 23:00.
function evening(t) { const m = hm(t); return m < 720 ? m + 1440 : m; }

$("#add").addEventListener("submit", e => {
  e.preventDefault();
  const match = normMatch($("#addMatch").value);
  const host = match.split("/")[0];
  if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(host)) { $("#msg").textContent = "Enter a site address like reddit.com or youtube.com/shorts."; return; }
  if (st.settings.rules.some(r => normMatch(r.match) === match)) { $("#msg").textContent = match + " is already on the list. Change its minutes above."; return; }
  const v = parseInt($("#addMin").value, 10);
  const label = $("#addLabel").value.trim() || host.replace(/\.(com|org|net|in|co\.in|tv|gg)$/, "").replace(/^./, c => c.toUpperCase());
  const rule = { id: match.replace(/[^a-z0-9]+/g, "-") + "-" + Date.now().toString(36), label, match, minutes: isNaN(v) ? 10 : Math.max(0, Math.min(600, v)) };
  $("#addMatch").value = ""; $("#addLabel").value = "";
  change(s => { if (!s.rules.some(r => r.id === rule.id)) s.rules.push(Object.assign({}, rule)); }, false);   // a new limit is stricter
});
$("#action").addEventListener("change", e => { const v = e.target.value; change(s => { s.action = v; }, v === "stay"); });
$("#allowExtra").addEventListener("change", e => { const v = e.target.checked; change(s => { s.allowExtra = v; }, v); });
$("#pause").addEventListener("change", e => { const v = e.target.checked; change(s => { s.pause = v; }, !v); });
$("#commit").addEventListener("change", e => { const v = e.target.checked; change(s => { s.commit = v; }, !v); });
$("#bedtime").addEventListener("change", e => { const v = e.target.checked; change(s => { s.bedtime = v; }, !v); });
$("#bedFrom").addEventListener("change", e => {
  const v = e.target.value; if (!/^\d\d:\d\d$/.test(v)) return;
  change(s => { s.bedFrom = v; }, st.settings.bedtime && evening(v) > evening(st.settings.bedFrom));
});
$("#bedTo").addEventListener("change", e => {
  const v = e.target.value; if (!/^\d\d:\d\d$/.test(v)) return;
  change(s => { s.bedTo = v; }, st.settings.bedtime && hm(v) < hm(st.settings.bedTo));
});
$("#snooze").addEventListener("click", async () => {
  const s = st.settings;
  if (s.snoozeUntil > Date.now()) s.snoozeUntil = 0;
  else if (s.commit && !firstDay() && s.snoozeDay === dayKey()) { $("#msg").textContent = "You've used today's snooze. It comes back tomorrow."; return; }
  else { s.snoozeUntil = Date.now() + 15 * 60000; s.snoozeDay = dayKey(); }
  await chrome.storage.local.set({ settings: s });
  render();
});

// Anonymous export a student can send their teacher: daily minutes and pause choices per limit.
async function anonId() {
  const { anonId: id } = await chrome.storage.local.get("anonId");
  if (id) return id;
  const a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789", r = new Uint8Array(8);
  crypto.getRandomValues(r);
  let s = "";
  r.forEach((b, i) => { if (i === 4) s += "-"; s += a[b % a.length]; });
  await chrome.storage.local.set({ anonId: s });
  return s;
}
$("#exportBtn").addEventListener("click", async () => {
  const cls = $("#classCode").value.trim().toUpperCase().replace(/\s+/g, "");
  if (!cls) { $("#msg").textContent = "Add the class code your teacher gave you first."; $("#classCode").focus(); return; }
  const id = await anonId();
  await chrome.storage.local.set({ classCode: cls });
  const all = await loadAll(), s = all.settings;
  const label = rid => { const r = s.rules.find(x => x.id === rid); return r ? r.label : rid; };
  const dates = [...new Set(Object.keys(all.usage).concat(Object.keys(all.stats)))].sort();
  const days = dates.map(d => {
    const items = {}, u = all.usage[d] || {}, st = all.stats[d] || {};
    new Set(Object.keys(u).concat(Object.keys(st))).forEach(rid => {
      items[label(rid)] = { seconds: Math.round(u[rid] || 0), opens: (st[rid] || {}).open || 0, backs: (st[rid] || {}).back || 0 };
    });
    return { date: d, items: items };
  });
  const out = {
    app: "TaktOwl Guard", format: 1, version: chrome.runtime.getManifest().version, exported: new Date().toISOString(),
    student: { id: id, class: cls, name: "" },
    settings: { pause: s.pause, commit: s.commit, bedtime: s.bedtime, bedFrom: s.bedFrom, bedTo: s.bedTo },
    limits: s.rules.map(r => ({ name: r.label, kind: "site", minutes: r.minutes })),
    days: days
  };
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(out, null, 1)], { type: "application/json" }));
  a.download = "TaktOwl-extension-" + cls.replace(/[^A-Z0-9-]/g, "") + "-" + id + "-" + dayKey() + ".json";
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  $("#msg").textContent = "Saved to your Downloads folder. Send it to your teacher.";
});
chrome.storage.local.get(["classCode"]).then(o => { if (o.classCode) $("#classCode").value = o.classCode; });
anonId().then(id => { $("#anonId").textContent = "Your ID: " + id; });

refresh();
setInterval(refresh, 5000);
