// Shared by the background worker, the popup, the pause page and the time's-up page.
// Defaults follow Hunt et al. 2018: about 10 minutes per social platform per day.
const DEFAULTS = {
  rules: [
    { id: "yt-shorts", label: "YouTube Shorts", match: "youtube.com/shorts", minutes: 10 },
    { id: "instagram", label: "Instagram", match: "instagram.com", minutes: 10 },
    { id: "facebook", label: "Facebook", match: "facebook.com", minutes: 10 },
    { id: "x", label: "X (Twitter)", match: "x.com", minutes: 10 },
    { id: "youtube", label: "YouTube", match: "youtube.com", minutes: 30 }
  ],
  action: "close",    // "close": the owl swats and the tab closes. "stay": the tab stays on the owl page.
  allowExtra: false,  // one 5-minute extension per site per day
  pause: true,        // one breath before opening a limited site (Gruning et al. 2023)
  commit: true,       // stricter settings now, looser ones tomorrow (Allcott et al. 2022)
  bedtime: true,
  bedFrom: "23:00",
  bedTo: "06:00",
  snoozeUntil: 0,
  snoozeDay: ""
};
const EXTRA_SECONDS = 300;
const PAUSE_SECONDS = 10;
const READMIT_MINUTES = 5;   // leave a site for longer than this and the pause comes back

const pad = n => String(n).padStart(2, "0");
function dayKey(d) { d = d || new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
function daysAgo(n) { const d = new Date(); d.setDate(d.getDate() - n); return dayKey(d); }
function tomorrow() { const d = new Date(); d.setDate(d.getDate() + 1); return dayKey(d); }

function normMatch(m) {
  return String(m || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/+$/, "");
}

// Most specific rule wins: "youtube.com/shorts" beats "youtube.com".
function matchRule(url, rules) {
  let u;
  try { u = new URL(url); } catch (e) { return null; }
  if (!/^https?:$/.test(u.protocol)) return null;
  const host = u.hostname.toLowerCase().replace(/^www\./, "");
  const path = u.pathname.toLowerCase();
  let best = null, bestLen = -1;
  for (const r of rules) {
    const m = normMatch(r.match);
    if (!m) continue;
    const i = m.indexOf("/");
    const h = i < 0 ? m : m.slice(0, i);
    const p = i < 0 ? "" : m.slice(i);
    if ((host === h || host.endsWith("." + h)) && (!p || path.startsWith(p)) && m.length > bestLen) {
      best = r; bestLen = m.length;
    }
  }
  return best;
}

function hm(s) { const p = String(s || "").split(":"); return (+p[0] || 0) * 60 + (+p[1] || 0); }
function inBedtime(settings, now) {
  if (!settings || !settings.bedtime) return false;
  now = now || new Date();
  const f = hm(settings.bedFrom), t = hm(settings.bedTo), n = now.getHours() * 60 + now.getMinutes();
  return f <= t ? n >= f && n < t : n >= f || n < t;
}

function secondsLeft(rule, usage, extra, settings) {
  if (inBedtime(settings)) return 0;
  const d = dayKey();
  const used = (usage[d] || {})[rule.id] || 0;
  const bonus = (extra[d] || {})[rule.id] || 0;
  return rule.minutes * 60 + bonus - used;
}

// Loads everything; looser settings saved for "tomorrow" take effect once that day arrives.
async function loadAll() {
  const s = await chrome.storage.local.get(["settings", "usage", "extra", "pending", "stats"]);
  let settings = Object.assign({}, DEFAULTS, s.settings || {});
  let pending = s.pending || null;
  if (pending && pending.applyOn <= dayKey()) {
    settings = Object.assign({}, DEFAULTS, pending.settings);
    pending = null;
    await chrome.storage.local.set({ settings: settings, pending: null });
  }
  return { settings: settings, usage: s.usage || {}, extra: s.extra || {}, pending: pending, stats: s.stats || {} };
}

// Counts pause openings and "back to work" choices per site per day.
async function bumpStat(ruleId, key) {
  const { stats = {} } = await chrome.storage.local.get("stats");
  const d = dayKey();
  stats[d] = stats[d] || {};
  stats[d][ruleId] = stats[d][ruleId] || { open: 0, back: 0 };
  stats[d][ruleId][key]++;
  const oldest = daysAgo(14);
  for (const k of Object.keys(stats)) if (k < oldest) delete stats[k];
  await chrome.storage.local.set({ stats: stats });
  return stats[d][ruleId];
}

// Close this tab; if it's the last one in its window, open a new tab page instead.
async function closeThisTab() {
  const me = await chrome.tabs.getCurrent();
  if (!me) { window.close(); return; }
  const siblings = await chrome.tabs.query({ windowId: me.windowId });
  if (siblings.length > 1) await chrome.tabs.remove(me.id);
  else await chrome.tabs.update(me.id, { url: "chrome://newtab/" });
}
